BasicGame.Controls = function (game) {

this.backButton = null;

};

BasicGame.Controls.prototype = {

create: function () {

// We've already preloaded our assets, so let's kick right into the Main Menu itself.
// Here all we're doing is playing some music and adding a picture and button
// Naturally I expect you to do something significantly better :)


var bg = this.add.sprite(0, 0, 'controlspage');
    


this.backButton = this.add.button(500, 470, 'backButton', this.startGame, this);


},

update: function () {
    


// Do some nice funky main menu effect here

},

startGame: function (pointer) {

    // And start the actual game
    this.game.state.start('MainMenu');


}

};
function Monster(){
    
};